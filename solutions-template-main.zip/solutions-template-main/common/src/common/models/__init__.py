"""
Flatten import namespace for models
"""

from .base_model import *
from .user import *
