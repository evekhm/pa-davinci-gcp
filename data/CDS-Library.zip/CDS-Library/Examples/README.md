# CDS-Library/Examples
The "rule" files for CRD and DTR that were not created as part of the reference implementation. For more documentation on the file structure, click [here](https://github.com/HL7-DaVinci/CDS-Library/CRD-DTR#file-layout]).
